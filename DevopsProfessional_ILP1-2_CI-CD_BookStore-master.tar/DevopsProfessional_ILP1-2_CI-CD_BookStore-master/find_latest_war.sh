# Latest War File #
## ls /home/osgdev/myPrj/com/devops/Demo2/1.0-SNAPSHOT/*.war | tail -1 | xargs cp -t ./ ##
## \rm -rf /home/osgdev/myPrj/com/devops/Demo2/1.0-SNAPSHOT/*  ##

ls /home/osgdev/DP_B18/DPB18/mavenProcess/com/devops/Demo3/1.0-SNAPSHOT/*.war | tail -1 | xargs cp -t ./
\rm -rf /home/osgdev/DP_B18/DPB18/mavenProcess/com/devops/Demo3/1.0-SNAPSHOT/*
