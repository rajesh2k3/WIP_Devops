#! /usr/bin/perl
print("Welcome to Devops PS\n");
print("Batch18\n");
print("Learning GIT & Demo Jenkins\n");

