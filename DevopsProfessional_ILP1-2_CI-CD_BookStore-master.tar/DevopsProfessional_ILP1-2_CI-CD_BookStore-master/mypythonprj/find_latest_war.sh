# Latest War File #
ls /home/osgdev/myPrj/com/devops/Demo2/1.0-SNAPSHOT/*.war | tail -1 | xargs cp -t ./
\rm -rf /home/osgdev/myPrj/com/devops/Demo2/1.0-SNAPSHOT/*
