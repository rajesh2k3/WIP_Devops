#Python Module Example#
#*********************#
def add (a,b):
    """ This program adds two numbers and tells if the result is >6 or <6 """
    result = a + b
    if result > 6:
       print("Sum is greater than 6")
    else:
       print("Sum is not greater than 6")

