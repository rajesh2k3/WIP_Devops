#Sum of >6 or <6 ?#
#*****************#
import sum
sum.add(4,5)

